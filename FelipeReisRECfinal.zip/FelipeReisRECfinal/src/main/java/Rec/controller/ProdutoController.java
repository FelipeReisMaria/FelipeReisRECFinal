package Rec.controller;

import Rec.model.Produto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProdutoController {

    @Autowired
    ProdutoServiceImpl produtoService;

    @GetMapping("/produto/list")
    public String List(Model model){
        model.addAttribute("produtos", produtoService.findAll());
        return "produto/list";
    }

    @GetMapping("/produto/add")
    public String addProduto(Model model) {
        model.addAttribute("produto", new Produto());
        model.addAttribute("produtos", produtoService.findAll());
        return "produto/add";
    }

    @PostMapping("/produto/save")
    public String save(Produto produto, Model model) {
        if (produtoService.save(produto)) {
            return "redirect:/produto/list";
        } else {
            model.addAttribute("produto", produto);
            return "produto/add";
        }
    }

    @GetMapping("/produto/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        model.addAttribute("produto", produtoService.findById(id));
        return "produto/edit";
    }

    @GetMapping("/produto/delete/{id}")
    public String delete(@PathVariable Long id) {
        if(produtoService.deleteById(id)) {
            return "redirect:/produto/list";
        } else {
            return "produto/list";
        }
    }
}
