package Rec.service;

import Rec.model.Produto;
import Rec.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoServiceImpl implements ProdutoService {

    @Autowired
    ProdutoRepository conteudoRepository;

    @Override
    public List<Produto> findAll(){
        return conteudoRepository.findAll();
    }

    @Override
    public boolean save(Produto conteudo) {
        try {
            if (conteudo != null) {
                conteudoRepository.save(conteudo);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public Produto findById(Long id) {
        return conteudoRepository.findById(id).get();
    }

    @Override
    public List<Produto> findByProduto(Produto produto) {
        return null;
    }

    @Override
    public List<Produto> findByAlunoIn(List<Produto> produtos) {
        return null;
    }

    @Override
    public List<Produto> findByProduto(Produto produto) {
        return conteudoRepository.findByProduto(produto);
    }

    @Override
    public List<Produto> findByProdutoIn(List<Produto> produtos) {
        List<Produto> produto;
        return conteudoRepository.findByProdutoIn(produto);
    }

    @Override
    public boolean deleteById(Long id) {
        try{
            conteudoRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

}
